#ifndef _INCLUDE_H_
#define _INCULDE_H_

#include <STC15.h>
#include <intrins.h>
#include "typedef.h"
#include "lsc2d.h"

#define FOSC 12000000L//22118400L      //System frequency

#define UART4_BAUD	9600

void InitUart(void);
void Uart1SendData(UINT8 dat);
void Uart1SendDataPacket(UINT8 dat[],uint8 len);

#endif
